#include "enemy1.h"

enemy1::enemy1()
{

}
