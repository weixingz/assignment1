#include "towerbase.h"
#include <QPixmap>
#include <QPainter>

towerbase::towerbase()
{

}
void towerbase::attack(){
}

void towerbase::setatower(){
}
void towerbase::towerability(){
}
void towerbase::upgradeatower(){}
void towerbase::sellatower(){}
void towerbase::show(QPainter * pa){
    QImage towerimg;
    towerimg.load("/Users/weixingz/Documents/programming/semester2/assignment2/picture/tow.jpg");
    pa->drawImage(200,200,towerimg);
}
