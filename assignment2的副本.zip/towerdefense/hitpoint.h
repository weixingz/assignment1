#ifndef HITPOINT_H
#define HITPOINT_H


class hitpoint
{
public:
    hitpoint();
    void damage(int d);
    void heal(int h);
protected:
    int point;
};

#endif // HITPOINT_H
