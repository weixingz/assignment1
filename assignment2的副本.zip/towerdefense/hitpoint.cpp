#include "hitpoint.h"

hitpoint::hitpoint()
{

}
void hitpoint::damage(int d){
    point-=d;
}
void hitpoint::heal(int h){
    point+=h;
}
