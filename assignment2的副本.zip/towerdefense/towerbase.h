#ifndef TOWERBASE_H
#define TOWERBASE_H
#include"hitpoint.h"
#include <QPaintEvent>
#include <QImage>
#include <QPainter>
class towerbase
{
public:
    towerbase();
    void attack();
    void show(QPainter * painter);
    void setatower();
    void towerability();
    void upgradeatower();
    void sellatower();
protected:
    hitpoint bt;
    bool live;
};

#endif // TOWERBASE_H
