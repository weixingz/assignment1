#include "enemybase.h"

enemybase::enemybase()
{

}
void enemybase::moveandattack(){

}
