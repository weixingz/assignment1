#ifndef ENEMYBASE_H
#define ENEMYBASE_H
#include"hitpoint.h"

class enemybase
{
public:
    enemybase();
    void moveandattack();
protected:
    hitpoint be;
    bool live;
};

#endif // ENEMYBASE_H
