#ifndef TOWER1_H
#define TOWER1_H
#include"towerbase.h"

class tower1 : public towerbase
{
public:
    tower1();

};

#endif // TOWER1_H
