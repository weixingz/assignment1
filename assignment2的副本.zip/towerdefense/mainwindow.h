#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_mainwindow.h"
#include"tower1.h"
#include"enemy1.h"
#include <QPaintEvent>
#include<iostream>
#include<QKeyEvent>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    //绘制事件
    void paintEvent(QPaintEvent *e);
    //键盘监听
    void keyPressEvent(QKeyEvent *);
protected slots:
    void move();
private:
    Ui::MainWindow *ui;
    QTimer *timer;
//地图切换功能待实现
//    background background_;
    enemy1 enemy_;
    tower1 tower_;
};

#endif // MAINWINDOW_H
