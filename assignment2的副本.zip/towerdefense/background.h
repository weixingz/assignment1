#ifndef BACKGROUND_H
#define BACKGROUND_H


class background
{
public:
    background();
};

#endif // BACKGROUND_H