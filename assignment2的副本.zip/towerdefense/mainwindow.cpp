#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"tower1.h"
#include"enemy1.h"
#include <QPixmap>
#include <QPainter>
#include<iostream>
#include <QTime>
#include<QTimer>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //调整大小
    setFixedSize(1000,800);
    //计时器
    timer = new QTimer();
    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    timer->start(0);
    //200ms一帧
    timer->setInterval(200);
}

MainWindow::~MainWindow()
{
    delete ui;
}

//显示
void MainWindow::paintEvent(QPaintEvent *e){
    QPainter painter(this);
    QPixmap back;
//    :/resourses/pictures/picture/backg.png
//相对路径不会写 先用绝对路径凑合
    back.load("/Users/weixingz/Documents/programming/semester2/assignment2/picture/backg.png");
    painter.drawPixmap(-100,0,1250,1000,back);
    QPixmap tow;
    tow.load("/Users/weixingz/Documents/programming/semester2/assignment2/picture/tow.jpg");
    painter.drawPixmap(500,500,300,200,tow);
    QPixmap enemy;
    enemy.load("/Users/weixingz/Documents/programming/semester2/assignment2/picture/timg.jpg");
    painter.drawPixmap(200,100,250,200,enemy);
    QPixmap fire;
    fire.load("/Users/weixingz/Documents/programming/semester2/assignment2/picture/fire.jpg");
    painter.drawPixmap(400,300,80,50,fire);
}

//键位
void MainWindow::keyPressEvent(QKeyEvent *e)
{
    if(e->key() == Qt::Key_Q)
    tower_.setatower();
    else if(e->key() == Qt::Key_W)
    tower_.upgradeatower();
    else if(e->key() == Qt::Key_E)
    tower_.sellatower();
    else if(e->key() == Qt::Key_R)
    tower_.towerability();
//    this->repaint();
}

void MainWindow::move(){
//防御塔和怪物在没有人干扰的情况下的自由运动
    tower_.attack();
//    enemy_.moveandattck();
    this->repaint();
}
