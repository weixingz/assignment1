#ifndef ENEMY1_H
#define ENEMY1_H
#include"enemybase.h"

class enemy1 : public enemybase
{
public:
    enemy1();
protected:
    hitpoint he;
};

#endif // ENEMY1_H
