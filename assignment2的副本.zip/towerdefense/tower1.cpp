#include "tower1.h"

tower1::tower1()
{

}
